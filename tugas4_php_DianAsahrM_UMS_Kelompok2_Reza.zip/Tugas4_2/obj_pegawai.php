<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tugas 4 PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>

  <body>
    <?php 
    require "Pegawai.php"; 

    $data = [
        [
            "nip" => "123456789", 
            "nama" => "Dian", 
            "jabatan" => "Manager",
            "agama" => "Kristen",
            "status" => "Menikah",
        ],

        [
            "nip" => "987654321", 
            "nama" => "Ashar", 
            "jabatan" => "Manager",
            "agama" => "Buddha",
            "status" => "Belum Menikah",
        ],

        [
            "nip" => "111111111", 
            "nama" => "Ma'ruf", 
            "jabatan" => "Staff",
            "agama" => "Islam",
            "status" => "Menikah",
        ],

        [
            "nip" => "22222222", 
            "nama" => "Ovi", 
            "jabatan" => "Asmen",
            "agama" => "Islam",
            "status" => "Belum Menikah",
        ],

        [
            "nip" => "333333333", 
            "nama" => "Ahamd", 
            "jabatan" => "Kabag",
            "agama" => "Kristen",
            "status" => "Belum Menikah",
        ],
    ]
    ?>

    <div class="container">
        <h1 class="text-center card text-bg-dark mb-3" style="max-width: 18rem;">Data Gaji Pegawai</h1>
            </hr>
            <div class="row">
                <?php 
                    foreach ($data as $pg) {
                        $nip = $pg['nip'];
                        $nama = $pg['nama'];
                        $jabatan = $pg['jabatan'];
                        $agama = $pg['agama'];
                        $status = $pg['status'];

                        $pegawai = new Pegawai($nip, $nama, $jabatan, $agama, $status);
                        $pegawai->mencetak();
                    }
                    ?>
            </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
  </body>
<h3 align="center"> Dian Ashar Ma'ruf</h3>
<h3 align="center"> Universitas Muhammadiyah Surakarta </h3>
<h3 align="center"> Kelompok 2 dgn Mentor Bp Reza</h3>
</html>